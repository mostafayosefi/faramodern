 <html>
<head>
</head>
<body>
<div style="direction:ltr;text-align:right;font-family:Tahoma;font-size:8pt;background-color:White">
<div marginwidth="0" marginheight="0" style="width:100%;margin:0;padding:0;background-color:#f5f5f5;font-family:tahoma"> 
<div style="display:block;min-height:5px;background-color:#32689a"></div> 
<center> 
<table border="0" cellpadding="0" cellspacing="0" height="100%" width="100%">
 <tbody>
<tr> 
<td align="center" valign="top" style="border-collapse:collapse;color:#525252"> 
<table border="0" cellpadding="0" cellspacing="0" width="700">
 <tbody><tr>
 <td align="center" valign="top" height="20" style="border-collapse:collapse;color:#525252"></td>
 </tr>
 <tr> 
 <td align="center" valign="top" style="border-collapse:collapse;color:#525252"> 
 <table width="100%" border="0">
 <tbody><tr>
 <td width="100%" align="center" style="border-collapse:collapse;color:#525252"> 
 <table border="0" cellpadding="0" cellspacing="0" style="margin-bottom:10px">
 <tbody><tr>
 <td width="641" height="34" align="center" style="border-collapse:collapse;color:#525252">
 <a href="#" style="width:80px;min-height:34px;display:block" target="_blank">
 </a> </td> </tr> 
 </tbody></table> </td> </tr> </tbody></table> </td> </tr> <tr> 
 <td align="center" height="38" style="border-collapse:collapse;color:#525252"></td> </tr> <tr> 
 <td align="center" valign="top" style="border-collapse:collapse;color:#525252"> 
 <table width="100%" valign="top" border="0" cellpadding="0" cellspacing="0">
 <tbody><tr> <td width="100%" style="direction:ltr;border-collapse:collapse;color:#525252;padding:10px;background-color:rgb(255,255,255);border-color:rgb(221,221,221);border-width:1px;border-radius:5px;border-style:solid;font-size:8pt;padding:15px 40px!important" align="justify" dir="ltr" valign="top">
 <table dir="ltr" style="direction:ltr"> 
 <tbody><tr> 
 <td style="border-collapse:collapse;color:#525252;padding:0px!important;text-align:justify;direction:ltr;font-family:Tahoma;line-height:20px;font-size:8pt" align="right" valign="top"> <br>
 <div style="font-size:15px;color:rgb(83,83,83);text-align:justify;font-weight:bold;font-family:Tahoma">

{{$titmes}} 

</div> 
 <br>
 {{$usernamee}} Hi  
 <br>
  
 {{$mestt}} : {{$mesnot}} 
<br>
Tanks
<br><br>
Farm Investment
<br>
 gamefarm.xyz
 <br><br> 

 </td> </tr> </tbody></table> </td> </tr> <tr> 
 <td align="center" valign="top" height="10" style="border-collapse:collapse;color:#525252"></td>
 </tr> <tr> <td align="center" valign="top" style="border-collapse:collapse;color:#525252"> 
 <table width="100%" valign="top" border="0" cellpadding="0" cellspacing="0" dir="ltr"> <tbody><tr>
 <td width="100%" style="border-collapse:collapse;color:#525252;padding:10px;background-color:rgb(255,255,255);border-color:rgb(221,221,221);border-width:1px;border-radius:5px;border-style:solid;font-size:8pt;padding:15px 40px!important" align="justify" valign="top"> 
 <p style="line-height:20px;font-family:Tahoma;font-size:8pt">
Note: This email has been sent automatically, so do not reply to it and wait for our email.

</p>
 </td> </tr> <tr>
 <td align="center" valign="top" height="10" style="border-collapse:collapse;color:#525252"></td> </tr> <tr> 
 <td width="100%" style="font-size:8pt;border-collapse:collapse;color:#525252;padding:10px;background-color:rgb(255,255,255);border-color:#e8e8e8;border-width:1px;border-radius:5px;border-style:solid;font-size:8pt;padding:15px 40px!important" align="left" valign="top"> <center>
 <a href="{{env('APP_URL')}}/" style="color:#999;text-decoration:none;font-family:Tahoma;font-size:8pt" target="_blank">Home</a>
&nbsp; |&nbsp;&nbsp;
  
 </center>
 </td> 
</tr> 
</tbody>
</table> </td>
 </tr> <tr>
 <td align="center" valign="top" height="33" style="border-collapse:collapse;color:#525252">
</td> </tr>
 <tr>
 <td style="border-collapse:collapse;color:#525252">

</td> </tr> <tr> 
<td align="center" valign="top" height="30" style="border-collapse:collapse;color:#525252">
 </td> </tr> </tbody></table> </td> </tr></tbody></table></center></div></div>
 </body>
 </html>
 
 